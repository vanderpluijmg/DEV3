var searchData=
[
  ['qsort',['qsort',['http://en.cppreference.com/w/cpp/algorithm/qsort.html',1,'std']]],
  ['queue',['queue',['http://en.cppreference.com/w/cpp/container/queue.html',1,'std::queue'],['http://en.cppreference.com/w/cpp/header/queue.html',1,'(Espace de nommage global)'],['http://en.cppreference.com/w/cpp/container/queue/queue.html',1,'std::queue::queue()']]],
  ['quick_5fexit',['quick_exit',['http://en.cppreference.com/w/cpp/utility/program/quick_exit.html',1,'std']]],
  ['quiet_5fnan',['quiet_NaN',['http://en.cppreference.com/w/cpp/types/numeric_limits/quiet_NaN.html',1,'std::numeric_limits']]],
  ['quot',['quot',['http://en.cppreference.com/w/cpp/numeric/math/div.html',1,'std::div_t::quot()'],['http://en.cppreference.com/w/cpp/numeric/math/div.html',1,'std::imaxdiv_t::quot()'],['http://en.cppreference.com/w/cpp/numeric/math/div.html',1,'std::ldiv_t::quot()'],['http://en.cppreference.com/w/cpp/numeric/math/div.html',1,'std::lldiv_t::quot()']]],
  ['quoted',['quoted',['http://en.cppreference.com/w/cpp/io/manip/quoted.html',1,'std']]]
];
