var searchData=
[
  ['first',['first',['http://en.cppreference.com/w/cpp/utility/pair.html',1,'std::pair']]],
  ['free',['free',['http://en.cppreference.com/w/cpp/experimental/fs/space_info.html',1,'std::experimental::filesystem::space_info::free()'],['http://en.cppreference.com/w/cpp/filesystem/space_info.html',1,'std::filesystem::space_info::free()']]]
];
