var searchData=
[
  ['alignment_5fof_5fv',['alignment_of_v',['http://en.cppreference.com/w/cpp/types/alignment_of.html',1,'std::alignment_of_v()'],['http://en.cppreference.com/w/cpp/experimental/type_trait_variable_templates.html',1,'std::experimental::alignment_of_v()']]],
  ['available',['available',['http://en.cppreference.com/w/cpp/experimental/fs/space_info.html',1,'std::experimental::filesystem::space_info::available()'],['http://en.cppreference.com/w/cpp/filesystem/space_info.html',1,'std::filesystem::space_info::available()']]]
];
