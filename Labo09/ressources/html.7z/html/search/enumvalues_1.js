var searchData=
[
  ['strict',['STRICT',['../classnvs_1_1lotto_1_1_lotto.html#a6a71e17fc29cee4c7648351d8394cce1a4c50b1af679a751969aaad2881a34bef',1,'nvs::lotto::Lotto']]]
];
