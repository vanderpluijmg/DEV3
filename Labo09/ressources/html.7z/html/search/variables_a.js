var searchData=
[
  ['owner_5f',['owner_',['../classnvs_1_1lotto_1_1_pronostic.html#ad7dbe8d4f8d4a7f05cd6ace2af4535ea',1,'nvs::lotto::Pronostic']]]
];
