var searchData=
[
  ['bit',['bit',['http://en.cppreference.com/w/cpp/header/bit.html',1,'']]],
  ['bitset',['bitset',['http://en.cppreference.com/w/cpp/header/bitset.html',1,'']]]
];
