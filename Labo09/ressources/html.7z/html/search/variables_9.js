var searchData=
[
  ['negation_5fv',['negation_v',['http://en.cppreference.com/w/cpp/types/negation.html',1,'std']]]
];
