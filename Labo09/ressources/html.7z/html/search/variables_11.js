var searchData=
[
  ['values_5f',['values_',['../classnvs_1_1lotto_1_1_item.html#a40227913c7d81916efe4e2d9cb1b107d',1,'nvs::lotto::Item']]],
  ['variant_5fsize_5fv',['variant_size_v',['http://en.cppreference.com/w/cpp/utility/variant/variant_size.html',1,'std']]]
];
