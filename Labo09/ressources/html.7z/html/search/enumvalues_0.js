var searchData=
[
  ['inclusive',['INCLUSIVE',['../classnvs_1_1lotto_1_1_lotto.html#a6a71e17fc29cee4c7648351d8394cce1a572d795e2d044f895cc511e5c05030e5',1,'nvs::lotto::Lotto']]]
];
