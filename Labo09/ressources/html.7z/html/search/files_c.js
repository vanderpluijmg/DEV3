var searchData=
[
  ['queue',['queue',['http://en.cppreference.com/w/cpp/header/queue.html',1,'']]]
];
