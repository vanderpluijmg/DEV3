var searchData=
[
  ['map',['map',['http://en.cppreference.com/w/cpp/header/map.html',1,'']]],
  ['memory',['memory',['http://en.cppreference.com/w/cpp/header/memory.html',1,'']]],
  ['memory_5fresource',['memory_resource',['http://en.cppreference.com/w/cpp/header/memory_resource.html',1,'']]],
  ['mutex',['mutex',['http://en.cppreference.com/w/cpp/header/mutex.html',1,'']]]
];
